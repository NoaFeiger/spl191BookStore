import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MessageBusImplTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void subscribeEvent() {
    }

    @Test
    public void subscribeBroadcast() {
    }

    @Test
    public void complete() {
    }

    @Test
    public void sendBroadcast() {
    }

    @Test
    public void sendEvent() {
    }

    @Test
    public void register() {
    }

    @Test
    public void unregister() {
    }

    @Test
    public void awaitMessage() {
    }

    @Test
    public void subscribeEvent1() {
    }

    @Test
    public void subscribeBroadcast1() {
    }

    @Test
    public void complete1() {
    }

    @Test
    public void sendBroadcast1() {
    }

    @Test
    public void sendEvent1() {
    }

    @Test
    public void register1() {
    }

    @Test
    public void unregister1() {
    }

    @Test
    public void awaitMessage1() {
    }
}