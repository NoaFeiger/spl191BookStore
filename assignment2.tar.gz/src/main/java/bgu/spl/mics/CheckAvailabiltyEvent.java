package bgu.spl.mics;

public class CheckAvailabiltyEvent<Boolean> implements Event {
}
