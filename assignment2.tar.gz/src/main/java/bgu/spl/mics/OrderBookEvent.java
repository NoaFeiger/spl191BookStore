package bgu.spl.mics;

public class OrderBookEvent<T> implements Event<T> {

}
