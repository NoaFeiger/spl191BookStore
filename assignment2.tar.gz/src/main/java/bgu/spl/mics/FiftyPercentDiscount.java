package bgu.spl.mics;

public class FiftyPercentDiscount implements Broadcast {

}
